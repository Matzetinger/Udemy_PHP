<?php
require_once("autoload.php");

use App\router\Router;

$router = new Router();
$router->add("GET", "/pokedex/", "HomeController@index");


$router->dispatch();