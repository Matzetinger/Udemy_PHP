<?php

namespace App\controllers;
use App\models\PokemonModel;


class HomeController extends BaseController{
  public function index(){

    
    $this->view("home", ["message" => "Hello Pokedex", "pokemon" => []]);
  }

  public function postindex(){

    $pokeModel = new PokemonModel;
    $pokemon = $_POST["pokemon"];

    $data = $pokeModel->getPokeData("https://pokeapi.co/api/v2/pokemon/$pokemon");

    
    if(!$data){
      $data["error"] = "No Pokemon found";
    }

    

    $this->view("home", ["message" => "Hello Pokedex", "pokemon" =>  $data]);
  }
}