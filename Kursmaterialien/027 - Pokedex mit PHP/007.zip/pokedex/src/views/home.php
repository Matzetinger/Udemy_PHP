<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pokedex</title>
</head>

<body>

  <h1><?php echo $message ?></h1>
  https://pokeapi.co/

  <form action="" method="post">
    <input type="text" name="pokemon" placeholder="Search Pokemon">
    <button type="submit">Search</button>
  </form>




  <?php if($pokemon): ?>
  <?php if($pokemon["error"] ?? []) : ?>
  <h3><?php echo $pokemon["error"] ?></h3>
  <?php else: ?>

  <div>
    <div class="cardheader">
      <img src="<?php echo $pokemon["sprites"]["front_default"] ?>" alt="Bild von einem Pokemon">
    </div>
    <div class="cardfooter">
      <h3><?php echo $pokemon["forms"][0]["name"] ?></h3>
    </div>
  </div>
  <?php endif; ?>
  <?php endif; ?>

</body>

</html>