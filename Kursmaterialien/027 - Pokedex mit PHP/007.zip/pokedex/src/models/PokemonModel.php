<?php

namespace App\models;

class PokemonModel{
  public function getPokeData($url){
    $curl = curl_init($url);

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, [
      'Content-Type: application/json'
    ]);


    $response = curl_exec($curl);


    if(curl_errno($curl)){
      echo "Error: " . curl_error($curl);
    }else{
      $decoded = json_decode($response, true);
      return $decoded;
    }

    curl_close($curl);
  }
}