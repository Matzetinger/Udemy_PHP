<?php

$url = "https://jsonplaceholder.typicode.com/posts/1";

$curl = curl_init($url);

curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, [
  'Content-Type: application/json'
]);


$response = curl_exec($curl);

if(curl_errno($curl)){
  echo "Error " . curl_error($curl);
}else{
  $decoded = json_decode($response, true);
  var_dump($decoded["title"]);
}

curl_close($curl);