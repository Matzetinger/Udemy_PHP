<?php

require_once("./Form/form.php");




$username = $_POST["username"];
$email = $_POST["email"];
$age = $_POST["age"];
$password = $_POST["password"];

echo "Mein Name ist $username, ich bin erreichbar unter $email und bin $age Jahre alt und mein Password ist $password"




?>





