<?php

require_once("./Form/form.php");


var_dump($_GET);










