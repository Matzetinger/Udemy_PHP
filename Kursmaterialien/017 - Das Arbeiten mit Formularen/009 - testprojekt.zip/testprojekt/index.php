<?php


$errormsg = null;


if($_SERVER["REQUEST_METHOD"] === "POST"){

  if(isset($_POST["send-login"])){


    switch (true) {
      case empty($_POST["username"]):
        $errormsg = "Username is not set yet!";
        break;

      case empty($_POST["email"]):
        $errormsg = "Email is not set yet!";
        break;

      case empty($_POST["age"]):
        $errormsg = "Age is not set yet!";
        break;

      case empty($_POST["password"]):
        $errormsg = "Password is not set yet!";
        break;

      case strlen(trim($_POST["password"])) < 8:
        $errormsg = "Password to short min(8)";
        break;

      case !filter_input(INPUT_POST, "email", FILTER_VALIDATE_IP):
        $errormsg = "Email has not a correct format";
        break;
    
      default:
        $errormsg = null;
        break;
    }



    if(!$errormsg){

      //Placholder
      $errormsg = "Formular korrekt abgesendet";
      $username = trim($_POST["username"]) ;
      $email = $_POST["email"];
      $password = $_POST["password"];
      $age = (int)$_POST["age"];

      // Validierung



      // Datenbank->


    }


    # https://www.w3schools.com/php/php_ref_string.asp
    # https://www.w3schools.com/php/php_filter.asp


  }
  
}


require_once("./Form/form.php");




?>





