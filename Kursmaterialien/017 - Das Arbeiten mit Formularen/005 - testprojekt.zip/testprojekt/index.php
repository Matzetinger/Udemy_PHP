<?php

require_once("./Form/form.php");





if($_SERVER["REQUEST_METHOD"] === "POST"){

  if(isset($_POST["send-login"])){
    echo "Login-Form sended";
  }
  
}








?>





