<?php 

class Vehicles{
  //Props
  private $color = "black";
  private $brand;

  //Methods
  function Hup($sound = "HUP HUP"){
    echo $sound;
  }

  // get & setter
  function getColor(){
    return $this->color;
  }

  
}


$Audi = new Vehicles;
echo $Audi->getColor();




?>