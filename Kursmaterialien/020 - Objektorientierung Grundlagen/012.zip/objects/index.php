<?php 

class Vehicle{
  //Props
  private $color = "black";
  private $brand;

  //Methods
  function Hup($sound = "HUP HUP"){
    echo $sound;
  }

  // get & setter
  function getColor(){
    return $this->color;
  }
  
  function setColor(){
    $this->color = "blue";
  }

  function getString(string $name) :string{
    return "Hello World $name";
  }

  
}


$Audi = new Vehicle;
//echo $Audi->getColor();


$BMW = new Vehicle;
$BMW->setColor();
echo $BMW->getColor();
echo $Audi->getColor();





?>