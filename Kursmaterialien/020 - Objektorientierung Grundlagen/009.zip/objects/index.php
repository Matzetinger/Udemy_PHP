<?php 

class Vehicles{
  //Props
  public $color = "black";
  public $brand;

  //Methods
  function Hup($sound = "HUP HUP"){
    echo $sound;
  }

}


$Audi = new Vehicles;
$Audi->brand = "audi";
echo $Audi->color . "<br>" . $Audi->brand . "<br>";
$Audi->Hup("AUDI HUPSOUND <br>");


$BMW = new Vehicles;
$BMW->color = "green";
$BMW->brand = "BMW";
echo $BMW->color . "<br>" .$BMW->brand . "<br>";
$BMW->Hup("BWM HUPSOUND");

$BMW7 = new Vehicles;
$BMW7->Hup();




?>