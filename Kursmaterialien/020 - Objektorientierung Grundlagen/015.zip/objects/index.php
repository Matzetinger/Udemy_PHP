<?php 

class Vehicle{
  //Props
  private $color = "black";
  private $brand;

  //Methods
  function Hup($sound = "HUP HUP"){
    echo $sound;
  }

  // get & setter
  function getColor(){
    return $this->color;
  }

  function setColor(){
    $this->color = "green";
  }
}


class Car extends Vehicle{
  //Props
  private $doors = 4;
  private $fuel;

  //Methods
  function playRadio($song){
    return $song;
  }
  function getDoors(){
    return $this->doors;
  }

  function Hup($sound = "BEEP BEEP"){
    parent::Hup($sound);
  }



}



$BMW = new Car();
$BMW->Hup("tü tp");










?>