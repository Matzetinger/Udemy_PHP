<?php 

class Vehicles{
  //Props
  public $color = "black";
  public $brand;

  //Methods
  function Hup(){
    echo "Hup Hup Sound";
  }

}


$Audi = new Vehicles;
$Audi->brand = "audi";
echo $Audi->color . "<br>" . $Audi->brand . "<br>";


$BMW = new Vehicles;
$BMW->color = "green";
$BMW->brand = "BMW";
echo $BMW->color . "<br>" .$BMW->brand;
$BMW->Hup();




?>