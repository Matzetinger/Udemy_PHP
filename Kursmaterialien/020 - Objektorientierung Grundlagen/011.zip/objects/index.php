<?php 

class Vehicles{
  //Props
  private $color = "black";
  private $brand;

  //Methods
  function Hup($sound = "HUP HUP"){
    echo $sound;
  }

  // get & setter
  function getColor(){
    return $this->color;
  }

  function getString(string $name) :string{
    return "Hello World $name";
  }

  
}


$Audi = new Vehicles;
echo $Audi->getColor();

$string = $Audi->getString("Lukas");
echo $string;




?>