<?php 


interface Drivable {
  public function startEngine();
  public function stopEngine();
  public function drive($speed);
}

interface Radio {
  public function playRadio();
}



class Vehicle implements Drivable, Radio{
  public function startEngine():static{
    echo "Engine started";
    return $this;
  }

  public function stopEngine(){
    echo "Engine stopped";
  }

  public function drive($speed):static{
    echo "Car is driving";
    return $this;
  }

  public function playRadio(){
    echo "The radio plays music";
  }
  
}

$Car = new Vehicle();
$Car->startEngine()->drive(60)->stopEngine();





?>