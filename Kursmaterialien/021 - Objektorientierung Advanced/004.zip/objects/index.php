<?php 

class Vehicle{
  //Props
  private $color;
  private $brand;

  public function __construct(string $color, string $brand){
    $this->color = $color;
    $this->brand = $brand;
  }

  function setProp($prop_name, $value){
    $this->$prop_name = $value;
  }

  function getProp($prop_name){
    return $this->$prop_name;
  }

}



$Auto = new Vehicle("blue", "Mercedes");
$Auto->setProp("color", "dark");
echo $Auto->getProp("color");
$Auto->setProp("brand", "Audi");
echo $Auto->getProp("brand");





?>