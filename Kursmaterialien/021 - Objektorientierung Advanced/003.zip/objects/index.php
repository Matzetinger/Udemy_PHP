<?php 

class Vehicle{
  //Props
  private $color;
  private $brand;

  public function __construct(string $color, string $brand){
    $this->color = $color;
    $this->brand = $brand;
  }

  function setColor($color){
    $this->color = $color;
  }
  function getColor(){
    return $this->color;
  }

}



$Auto = new Vehicle("blue", "Mercedes");
echo $Auto->getColor();


$Auto2 = new Vehicle("red", "BMW");
echo $Auto2->getColor();




?>