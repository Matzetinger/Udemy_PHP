<?php 

interface Greeter{
  public function greet();
}


$greeter = new class("Patrick") implements Greeter{

  public const LASTNAME = "Mustermann";

  public function __construct(private string $name){}
  public function greet(){
    echo "Hello World " . $this->name . " " . self::LASTNAME;
  }
};

echo $greeter::LASTNAME;

$greeter->greet();







?>