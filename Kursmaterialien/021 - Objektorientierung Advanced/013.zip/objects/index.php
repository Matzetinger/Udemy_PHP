<?php 

abstract class Vehicle{
  protected $brand;

  abstract public function startEngine();

  public function setBrand($brand):static{
    $this->brand = $brand;
    return $this;
  }

  public function getBrand(){
    return $this->brand;
  }

}



class Car extends Vehicle{
  
  public function startEngine(){
    return "Engine ist started";
  }
}


$BMW = new Car;
echo $BMW->setBrand("bmw")->getBrand();
echo $BMW->startEngine();







?>