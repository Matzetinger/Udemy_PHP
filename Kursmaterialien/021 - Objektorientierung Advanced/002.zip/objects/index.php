<?php 

class Vehicle{
  //Props
  private $color = "black";
  private $brand;
  //Methods
  function Hup($sound = "HUP HUP"){
    echo $sound;
  }
  // get & setter
  function getColor(){
    return $this->color;
  }

  function setColor(){
    $this->color = "green";
  }
}


$Audi = new Vehicle();
echo $Audi->getColor();

$Audi2 = clone $Audi;
$Audi2->setColor();
echo $Audi2->getColor();
echo $Audi->getColor();







?>