<?php 

class Vehicle{
  //Props
  
  public function __construct(private string $color, private string $brand){}

  function setProp($prop_name, $value){
    $this->$prop_name = $value;
  }

  function getProp($prop_name){
    return $this->$prop_name;
  }

}



$Auto = new Vehicle("blue", "Mercedes");
$Auto->setProp("color", "dark");
echo $Auto->getProp("color");
$Auto->setProp("brand", "Audi");
echo $Auto->getProp("brand");





?>