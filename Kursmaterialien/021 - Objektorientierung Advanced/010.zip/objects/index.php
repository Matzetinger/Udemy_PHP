<?php 




class Vehicle{
  //Props
  public function __construct(public readonly string $test){}
  

}



$Car = new Vehicle("Hello");
$Car->test = "Bye";
echo $Car->test;













?>