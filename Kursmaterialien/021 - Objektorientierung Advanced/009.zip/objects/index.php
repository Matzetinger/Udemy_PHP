<?php 




class DatabaseHandle{
  //Props
  public final static function getData(){

    var_dump(["Melanie", "Steffen", "Baris", "Ayhem"]);

  }

  public static function postData(){

  }

  public static function putData(){

  }

}
DatabaseHandle::getData();


class Test extends DatabaseHandle{

  public function getData(){
    echo "Hello World";
  }

}











?>