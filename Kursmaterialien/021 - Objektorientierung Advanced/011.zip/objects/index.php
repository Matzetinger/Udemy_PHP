<?php 


interface Drivable {
  public function startEngine();
  public function stopEngine();
  public function drive($speed);
}

interface Radio {
  public function playRadio();
}



class Vehicle implements Drivable, Radio{
  public function startEngine(){
    echo "Engine started";
  }

  public function stopEngine(){
    echo "Engine stopped";
  }

  public function drive($speed){
    echo "Car is driving";
  }

  public function playRadio(){
    echo "The radio plays music";
  }
  
}

$Car = new Vehicle();
$Car->drive(60);






?>