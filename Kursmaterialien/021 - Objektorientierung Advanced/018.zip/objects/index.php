<?php 


class Person{

  public $email = "lkdshfk";

  private $data = [
    "name" => "Max Mustermann",
    "age" => 25,
    "address" => null
  ];



  public function __set($name, $value){
    if(array_key_exists($name, $this->data)){
      if($name === "age" && !is_numeric($value)){
        throw new  Exception("Age musst be numeric");
      }
      $this->data[$name] = $value;
    }else{
      throw new  Exception("This prop does not exists");
    }
  }



  public function __get($name){
    if(array_key_exists($name, $this->data)){
      return $this->data[$name];
    }else{
      throw new  Exception("This prop does not exists");
    }
  }


}

$person = new Person;
$person->age = 30;
$person->name = "Louisa";
$person->address = "dskfdgkdshg";


echo $person->age;
echo $person->name;
echo $person->address;


?>