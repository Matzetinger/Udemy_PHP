<?php 


class DatabaseHandle{
  //Props
  public static function getData(){

    var_dump(["Melanie", "Steffen", "Baris", "Ayhem"]);

  }

  public static function postData(){

  }

  public static function putData(){

  }

}

DatabaseHandle::getData();











?>