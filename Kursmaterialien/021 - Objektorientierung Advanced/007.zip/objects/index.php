<?php 


class Vehicle{
  //Props

  protected $name = "Melanie";
  
  private function getName(){
    echo $this->name;
  }


  public function getTest(){
    echo $this->getName();
  }
}


class Car extends Vehicle{
  public function getNewName(){
    echo $this->name;
  }
}



$Auto = new Vehicle();

$Test = new Car();
$Test->getNewName()








?>