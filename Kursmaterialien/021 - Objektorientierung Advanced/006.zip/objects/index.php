<?php 



class FileHandler{
  private $fileHandle;

  public function __construct(private string $filename){
    $this->fileHandle = fopen($filename, "w");
    if($this->fileHandle){
      echo "File successful open";
    }
  }

  public function writeData(string $data){
    if(fwrite($this->fileHandle, $data) === false){
      echo "Error with writing this File";
    }else{
      echo "Successful writing in file";
    }
  }

  public function __destruct(){
    if($this->fileHandle){
      fclose($this->fileHandle);
      echo "Closed filehandler";
    }
  }
}


$File = new FileHandler("text.txt");
$File->writeData("Hello World");
unset($File);




class Vehicle{
  //Props

  public function __construct(private string $color, private string $brand){}

  function setProp($prop_name, $value){
    $this->$prop_name = $value;
  }

  function getProp($prop_name){
    return $this->$prop_name;
  }


  public function __destruct(){
    echo "Objekt entfernt";
  }

}


$Auto = new Vehicle("blue", "Mercedes");
$Auto->setProp("color", "dark");
echo $Auto->getProp("color");






?>