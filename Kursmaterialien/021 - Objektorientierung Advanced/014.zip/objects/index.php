<?php 

interface Greeter{
  public function greet();
}


$greeter = new class("Patrick") implements Greeter{

  public function __construct(private string $name){}
  public function greet(){
    echo "Hello World " . $this->name;
  }
};

$greeter->greet();

$greeter2 = new $greeter("Thomsen");
$greeter2->greet();






?>