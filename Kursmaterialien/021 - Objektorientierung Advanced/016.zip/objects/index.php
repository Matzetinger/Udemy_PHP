<?php 


class Printer{
  public function print($document, $copyNumber = 1){
    echo "Print " . $document . " with " . $copyNumber . " copys" . "<br>";
  }
}


$printer = new Printer;
$printer->print("File 1");
$printer->print("File 3", 10);


class Calculator{
  public function add(...$numbers){
    echo array_sum($numbers) . "<br>";
  }
}

$calc = new Calculator;
$calc->add(1,2,5);
$calc->add(6,7,8,9,10);


class FlexiblePrinter{
  public function __call($name, $arguments){
    if($name === "print"){
      $document = $arguments[0];
      $copies = $arguments[1] ?? 1;
      echo "Print " . $document . " with " . $copies . " copys" . "<br>";
    }elseif ($name === "hello") {
      echo $arguments[0] . " " . $arguments[1] . " " . $arguments[2];
    }
  }
}

$newprinter = new FlexiblePrinter;
$newprinter->print("document1", 3);
$newprinter->hello("Hello World", "Jessica", "whats up");





?>