<?php 


trait Testtrait{
  public $name;

  public function setName($name){
    $this->name = $name;
  }

  public function getName(){
    return $this->name;
  }
}


trait Test{
  public $name;

  public function setName($name){
    $this->name = $name;
  }
}


class Person{
  use Testtrait, Test{
    Testtrait::setName insteadOf Test;
    Test::setName as setThisName;
  }
}


$steffen = new Person;
$steffen->setName("Steffen");
echo $steffen->getName();
$steffen->setThisName("Simon");
echo $steffen->getName()





?>