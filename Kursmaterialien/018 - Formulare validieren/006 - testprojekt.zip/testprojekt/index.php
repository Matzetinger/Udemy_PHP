<?php


$ok = true;
$errormsg = null;


if($_SERVER["REQUEST_METHOD"] === "POST"){

  if(isset($_POST["send-login"])){

    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $age = (int)trim($_POST["age"]);
    $password = trim($_POST["password"]);
    $passwort_pattern = '/^(?=.*[A-Z])(?=.*[a-z])(?=.*[@$!.*?%&§])(?=.*\d)[A-Za-z\d@$!.*?%&§]{8,16}$/';


    switch (true) {

      # Username
      case empty($username):
        $errormsg = "Username is not set yet!";
        $ok = false;
        break;

      case !ctype_alpha($username):
        $errormsg = "Only letters are allowed";
        $ok = false;
        break;

      # Email
      case empty($email):
        $errormsg = "Email is not set yet!";
        $ok = false;
        break;

      case !filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL):
        $errormsg = "Email has not a correct format";
        $ok = false;
        break;

  
      # Password
      case empty($password):
        $errormsg = "Password is not set yet!";
        $ok = false;
        break;


      case !(bool)preg_match($passwort_pattern, $password):
        $errormsg = "The password is not in the right format.";
        $ok = false;
        break;


      case $_POST["age"] !== "":
        switch (true) {
          case !filter_var($age, FILTER_VALIDATE_INT, ["options" => ["min_range" => 0, "max_range" => 120]]):
            $errormsg = "This is age, is not in the right range or format!";
            $ok = false;
            break;
        }

        break;

    
      default:
        $ok = true;
        $errormsg = null;
        break;
    }


    // Wenn errormsg is false
    if($ok){
      $errormsg = "Formular korrekt abgesendet";
      $username = null; 
      $password = null;
      $age = null;
      $email = null;
    
    }

  }
  
}




// Password
// 8 - 16 Zeichen #
// Mindestens ein Großbuchstabe # 
// Mindestens ein Kleinbuchstabe  #
// Mindestens eine Zahl  # 
// Mindesten ein Sonderzeichen #


// Metazeichen: Spezielle Zeichen mit besonderer Bedeutung.
// .: Ein beliebiges Zeichen (außer einem Zeilenumbruch).
// ^: Anfang der Zeichenkette.
// $: Ende der Zeichenkette.
// *: Null oder mehr des vorherigen Zeichens.
// +: Eins oder mehr des vorherigen Zeichens.
// ?: Null oder eins des vorherigen Zeichens.
// []: Zeichenklasse. Beispiel: [a-z] findet alle Kleinbuchstaben.
// \: Escape-Zeichen, um Metazeichen zu maskieren.
// \d: Digit 0-9 [0-9] //Beispiel \
// Quantifizierer: Bestimmen die Anzahl der Vorkommen.
// {n}: Genau n Vorkommen.
// {n,}: Mindestens n Vorkommen.
// {n,m}: Zwischen n und m Vorkommen.
// Gruppierung: Runde Klammern () werden verwendet, um Gruppen zu erstellen und Operationen zu steuern.










require_once("./Form/form.php");


?>





