<?php


$ok = true;
$errormsg = null;


if($_SERVER["REQUEST_METHOD"] === "POST"){

  if(isset($_POST["send-login"])){


    switch (true) {
      case empty($_POST["username"]):
        $errormsg = "Username is not set yet!";
        $ok = false;
        break;

      case empty($_POST["email"]):
        $errormsg = "Email is not set yet!";
        $ok = false;
        break;

      case empty($_POST["age"]):
        $errormsg = "Age is not set yet!";
        $ok = false;
        break;

      case empty($_POST["password"]):
        $errormsg = "Password is not set yet!";
        $ok = false;
        break;

      case strlen(trim($_POST["password"])) < 8:
        $errormsg = "Password to short min(8)";
        $ok = false;
        break;

      case !filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL):
        $errormsg = "Email has not a correct format";
        $ok = false;
        break;
    
      default:
        $ok = true;
        $errormsg = null;
        break;
    }


    // Wenn errormsg is false
    if($ok){

      //Placholder
      $errormsg = "Formular korrekt abgesendet";
      $username = trim($_POST["username"]) ;
      $email = $_POST["email"];
      $password = $_POST["password"];
      $age = (int)$_POST["age"];


    }

  }
  
}


require_once("./Form/form.php");


?>





