<form action="" method="post">
  <label for="date">Your Date</label>
  <input type="datetime-local" name="date" id="date">
  <button type="submit">Calculate</button>
</form>